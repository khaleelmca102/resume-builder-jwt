<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($title); ?></title>
</head>
<body>
    <p><?php echo e($title); ?> <?php echo e($description); ?></p>

    <br>

    <p>Put your text here.</p>

    <p>Place your dynamic content here.</p>

    <br>

    <p style="text-align: center;"><?php echo $footer; ?></p>
</body>
</html><?php /**PATH E:\react\resume-bulider\backend\resources\views/testPDF.blade.php ENDPATH**/ ?>